package com.ust.test;

public class Sample {

	public static void main(String[] args) {
		byte a=10;
		byte b=10;
		byte c=(byte)(a+b);
		System.out.println(c);
		
		// TODO Auto-generated method stub

	}

}
