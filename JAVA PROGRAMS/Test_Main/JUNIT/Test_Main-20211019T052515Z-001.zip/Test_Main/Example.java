package com.ust.test;

public class Example {
	
	int age;
	String name;
	float salary;
	
	public void display() {
		System.out.println("Hello world");
	}
	
	public static void main(String args[]) {
		Example ex=new Example();
		ex.display();
	}
	

}
