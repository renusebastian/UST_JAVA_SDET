package com.ust.test;

public class ArrayLatForExample {

	public static void main(String[] args) {
		int[] age= {1,15,16};
		System.out.println("Usage of for loop");
		for(int a: age) {
			System.out.println(a);
	}

}
}
