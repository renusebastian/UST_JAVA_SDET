package com.ust.Test_Main;

public class Hello {

	public static void main(String[] args) {
		System.out.println("HI JAVA");
	}
}
