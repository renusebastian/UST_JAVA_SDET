package com.ust.test;

public class PostPreIncrement {

	public static void main(String[] args) {
		int a =6, b = 6;
		System.out.println(a++);
		System.out.println(++b);

	}

}
