package com.ust.test;


class test_this{
	void print() {
		this.show();
		System.out.println("This is print");
		
	}
	
	void show() {
		System.out.println("This is show");
	}
}

public class This_Example3{
	public static void main(String[] args) {
		test_this t=new test_this();
		t.print();
	}
		// TODO Auto-g

	}










/*package com.ust.test;

class ClassJava{
	int a;
	String s;
	static int name;
	
	void increment() {
		a=a+1;
		System.out.println(a);
	}
	
	static int name() {
		name=name+1;
	}
	
	private classJava(){
		a=0;
		s="abc";
		
		
	}
	

public class ClassJava {
	
		
		
				
	}
	
	
	

	public static void main(String[] args) {
		int 
	

	}

}
*/
