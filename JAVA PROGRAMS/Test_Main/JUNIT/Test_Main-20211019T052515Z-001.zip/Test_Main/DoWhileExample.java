package com.ust.test;

public class DoWhileExample {

	public static void main(String[] args) {
		float i=0;
		do{
			System.out.println(i);
			i++;
		}
		while(i<5);
	}

}
