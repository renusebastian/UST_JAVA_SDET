package com.ust.test;

public class WhileExample {

	public static void main(String[] args) {
		float i=0.1f;
		while(i<5.0) {
			System.out.println(i);
			i++;
		}
		

	}

}
