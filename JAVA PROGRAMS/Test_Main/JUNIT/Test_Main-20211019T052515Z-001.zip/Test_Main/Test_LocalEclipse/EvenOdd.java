package com.ust.test;

public class EvenOdd {

	public static void main(String[] args) {
		int number=8;
		if(number%2==0){
			System.out.println("It is an even number");
			
		}
		else {
			System.out.println("It is a odd number");
			
		}
		// TODO Auto-generated method stub

	}

}
