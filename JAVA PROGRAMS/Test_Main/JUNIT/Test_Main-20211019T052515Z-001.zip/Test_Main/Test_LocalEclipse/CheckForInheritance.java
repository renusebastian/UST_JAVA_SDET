package com.ust.test;

class CheckForInheritance {
	 void teach() {
	  System.out.println("Teaching subjects");
	 }
	}
	class Students extends CheckForInheritance {
	 void listen() {
	  System.out.println("Listening to teacher");
	 }
	}
	class CheckForInheritance {
	 public static void main(String args[]) {
	  Students s1 = new Students();
	  s1.teach();
	  s1.listen();
	 }
	}
