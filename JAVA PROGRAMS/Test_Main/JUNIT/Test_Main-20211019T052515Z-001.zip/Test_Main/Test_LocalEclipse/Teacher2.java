package com.ust.test;

public class Teacher2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
