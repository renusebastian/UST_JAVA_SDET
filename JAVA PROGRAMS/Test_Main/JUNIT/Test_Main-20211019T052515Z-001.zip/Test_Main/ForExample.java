package com.ust.test;

public class ForExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(float i=0.1f;i<5.0;i++) {
			System.out.println(i);
		}

	}

}
