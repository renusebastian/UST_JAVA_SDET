package com.ust.test;

public class MethodOverRidingExample3 {
	void teach() {
		System.out.println("Teaching subject");
	}
	}
class MethodOverRidingExample3_{
	public static void main(String[] args) {
		MethodOverRidingExample3 d=new MethodOverRidingExample3();
		d.teach();
	}
		
 
	} 
Code wrong, Need to correct on it